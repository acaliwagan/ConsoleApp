﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class ConvertToUpperCase
    {
    }

    private void ToUpper(string str)
    {
        try
        {
            string converted = str.ToUpper(str);
        }
        catch (NullReferenceException n)
        {
            throw n;
        }
    }
}
