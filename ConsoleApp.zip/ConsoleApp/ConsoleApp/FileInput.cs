﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class FileInput
    {
    }

    private void FileInput(string path)
    {
        string filePath = Path.GetDirectoryName(path);

        if (!File.Exists(filePath))
        {
            using (FileStream fs = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.None))
            {
                byte[] b = new byte[1024];
                UTF8Encoding temp = new UTF8Encoding(true);

                while (fs.Read(b,0,b.Length) > 0)
                {
                    Console.WriteLine(temp.GetString(b));
                }
            }
        }
        else
        {
            throw new FileNotFoundException();
        }
    }
}
