﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class CheckInt
    {
    }

    private void CheckInteger(int input)
    {
        if (input < 0 || input > 1000)
        {
            throw new Exception();
        }
    }

    private void CheckInt32(List<int> input)
    {
        uint result = 0;

        foreach(int intInput in input)
        {
            if (UInt32.TryParse(intInput, out result))
            {

            }
            else
            {
                throw new Exception();
            }
        }
    }
}
