﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class ConvertToInt
    {
    }

    private void ConvertToInt(string num)
    {
        try
        {
            int n = Convert.ToInt32(num);
        }
        catch (FormatException f)
        {
            throw f;
        }
    }
}
