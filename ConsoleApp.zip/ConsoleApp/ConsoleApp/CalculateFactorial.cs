﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class CalculateFactorial
    {
    }

    private void CalcFactorial(int num)
    {
        try
        {
            int factorial;
            while (num > 0)
            {
                factorial = num;
                for (int i = factorial - 1; i > 0; i--)
                {
                    factorial *= i;
                }
                factorial--;
            }
        }
        catch(OverflowException o)
        {
            throw o;
        }

    }
}
