﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class DivideNumbers
    {
    }

    private void Divide(double a, double b)
    {
        try
        {
            double answer = a / b;
        }
        catch (DivideByZeroException d)
        {
            throw d;
        }

    }
}
