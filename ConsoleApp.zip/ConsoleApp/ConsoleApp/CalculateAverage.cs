﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class CalculateAverage
    {
    }

    private void CalcAve(int[] values)
    {
        try
        {
            int sum = 0;
            int average = 0;
            for (int i = 0; i < values.Length; i++)
            {
                sum += values[i];
            }
            average = sum / values.Length;
        }
        catch ( ArgumentException a)
        {
            throw a;
        }

    }
}
