﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    internal class CalcSqrt
    {
    }

    private void Calculate(double num)
    {
        if (num > 0)
        {
            double squareRoot = Math.Sqrt(num);
        }
        else
        {
            throw new Exception();
        }
    }
}
